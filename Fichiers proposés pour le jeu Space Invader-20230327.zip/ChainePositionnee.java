public class ChainePositionnee{
    int x,y;
    String c;
    public ChainePositionnee(int a,int b, String d){x=a; y=b; c=d;}
}
